# Digital Clock ⏰

A simple **Digital Clock** built with Python and Tkinter.

## Features
- Displays current time in HH:MM:SS format
- Updates every second
- Simple GUI

## Requirements
- Python 3.x
- Tkinter (comes pre-installed with Python)

## Run the Project
```bash
python clock.py
```
