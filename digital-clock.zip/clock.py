import tkinter as tk
from time import strftime

# Create main window
root = tk.Tk()
root.title("Digital Clock")
root.geometry("400x200")
root.resizable(False, False)
root.configure(bg="black")

# Clock display
label = tk.Label(root, font=("Helvetica", 48), bg="black", fg="cyan")
label.pack(anchor="center", expand=True)

def update_time():
    current_time = strftime("%H:%M:%S")
    label.config(text=current_time)
    label.after(1000, update_time)  # Update every second

update_time()
root.mainloop()
